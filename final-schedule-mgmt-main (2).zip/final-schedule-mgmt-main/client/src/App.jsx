// import './App.css'
import Schedule from './components/Schedule'

function App() {
  

  return (
    <>
      <Schedule/>
    </>
  )
}

export default App
