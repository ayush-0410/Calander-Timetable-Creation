
# Timetable Schedular




## To start Frontend

Move to client folder and open terminal

```bash
  npm install 
  npm run dev
```


## To start Backend

Move to server folder and open terminal

```bash
  npm install 
  npm i nodemon
  nodemon index.js
```
    